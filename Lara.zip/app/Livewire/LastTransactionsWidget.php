<?php

namespace App\Livewire;

use Filament\Widgets\Widget;

class LastTransactionsWidget extends Widget
{
    protected static string $view = 'livewire.last-transactions-widget';
}
