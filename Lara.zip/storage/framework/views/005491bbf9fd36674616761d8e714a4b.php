<?php $__env->startSection('content'); ?>

<h1 class="fw-bold text-primary mb-4">Demandes de retrait</h1>

<div class="table-card shadow-lg">

    <table class="table-modern">
        <thead>
            <tr>
                <th>ID</th>
                <th>Utilisateur</th>
                <th>Montant</th>
                <th>Méthode</th>
                <th>Destinataire</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($w->id); ?></td>
                <td><?php echo e($w->user->name); ?></td>
                <td><?php echo e(number_format($w->amount)); ?> XOF</td>
                <td><?php echo e(ucfirst($w->method)); ?></td>
                <td><?php echo e($w->recipient); ?></td>

                <td>
                    <?php if($w->status == 'approved'): ?>
                        <span class="badge-modern badge-approved">Approuvé</span>
                    <?php elseif($w->status == 'pending'): ?>
                        <span class="badge-modern badge-pending">En attente</span>
                    <?php elseif($w->status == 'completed'): ?>
                        <span class="badge bg-info">Terminé</span>
                    <?php else: ?>
                        <span class="badge-modern badge-none">Rejeté</span>
                    <?php endif; ?>
                </td>

                <td><?php echo e($w->created_at->format('d/m/Y')); ?></td>

                <td>
                    <a href="<?php echo e(route('admin.withdrawals.show', $w->id)); ?>" class="btn btn-primary btn-sm">
                        Voir
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($withdrawals->links('vendor.pagination.custom')); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/withdraw/index.blade.php ENDPATH**/ ?>