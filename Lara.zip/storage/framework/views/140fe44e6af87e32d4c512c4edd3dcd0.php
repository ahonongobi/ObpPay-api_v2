<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<h1 class="fw-bold text-primary mb-4">Modifier l’utilisateur</h1>

<div class="card shadow-lg p-4 rounded-4 edit-card">

    <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row g-4">

            <!-- NOM -->
            <div class="col-md-6">
                <label class="form-label fw-bold">Nom complet</label>
                <input type="text" name="name" class="form-control" 
                       value="<?php echo e($user->name); ?>" required>
            </div>

            <!-- PHONE -->
            <div class="col-md-6">
                <label class="form-label fw-bold">Téléphone</label>
                <input type="text" name="phone" class="form-control" 
                       value="<?php echo e($user->phone); ?>" required>
            </div>

            <!-- EMAIL -->
            <div class="col-md-6">
                <label class="form-label fw-bold">Email</label>
                <input type="email" name="email" class="form-control"
                       value="<?php echo e($user->email); ?>">
            </div>

            <!-- STATUS -->
            <div class="col-md-6">
                <label class="form-label fw-bold">Status</label>
                <select name="status" class="form-select">
                    <option value="active" <?php echo e($user->status == 'active' ? 'selected' : ''); ?>>
                        Actif
                    </option>
                    <option value="blocked" <?php echo e($user->status == 'blocked' ? 'selected' : ''); ?>>
                        Bloqué
                    </option>
                </select>
            </div>

            <!-- BALANCE -->
            <div class="col-md-6">
            <label class="form-label fw-bold">Balance (XOF)</label>
            <input type="number" name="balance" step="0.01" class="form-control"
                value="<?php echo e($user->wallet->balance ?? 0); ?>" required>
             </div>


        </div>

        <!-- BUTTONS -->
        <div class="d-flex justify-content-end mt-4 gap-3">
            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-secondary">
                Annuler
            </a>
            <button type="submit" class="btn btn-primary px-4">
                Mettre à jour
            </button>
        </div>
    </form>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<style>
/* DARK MODE SUPPORT */
body.dark-mode .edit-card {
    background: #1f2937 !important;
    color: #e5e7eb;
    border: 1px solid rgba(255,255,255,0.05);
}

body.dark-mode .form-control,
body.dark-mode .form-select {
    background: #111827 !important;
    color: #e5e7eb !important;
    border: 1px solid #374151 !important;
}

body.dark-mode label {
    color: #e5e7eb !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>