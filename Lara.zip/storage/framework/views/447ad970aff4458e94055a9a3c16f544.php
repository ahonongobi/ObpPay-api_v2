<style>
    /* SEARCH CONTAINER */
.search-container {
    position: relative;
}

/* ICON INSIDE INPUT */
.search-icon {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: #6b7280;
    font-size: 1.1rem;
    pointer-events: none;
}

/* INPUT */
.search-input {
    padding-left: 40px !important;
    border-radius: 12px;
    height: 44px;
    border: 1px solid #d1d5db;
    transition: .2s;
}

/* FOCUS EFFECT */
.search-input:focus {
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99,102,241,.2);
}

/* DARK MODE */
body.dark-mode .search-input {
    background: #1f2937;
    border: 1px solid #374151;
    color: #e5e7eb;
}

body.dark-mode .search-input::placeholder {
    color: #9ca3af;
}

body.dark-mode .search-icon {
    color: #9ca3af;
}

body.dark-mode .search-input:focus {
    border-color: #818cf8;
    box-shadow: 0 0 0 3px rgba(129,140,248,.25);
}

</style>
<?php $__env->startSection('content'); ?>

<h1 class="fw-bold text-primary mb-4">Gestion des utilisateurs</h1>

<!-- SEARCH + EXPORT -->
<div class="d-flex justify-content-between align-items-center mb-3">

    <!-- SEARCH BOX -->
    <div class="search-container w-50 position-relative">
        <i class="bi bi-search search-icon"></i>
        <input type="text" id="userSearch" class="form-control search-input"
               placeholder="Rechercher un utilisateur..." onkeyup="filterUsers()">
    </div>

    <!-- EXPORT CSV -->
    <button onclick="exportUsersCSV()" class="btn btn-outline-primary shadow-sm">
        <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
    </button>
</div>

<!-- TABLE -->
<div class="table-card shadow-lg">

    <table class="table-modern w-100" id="usersTable">
        <thead>
            <tr>
                <th>#OBP ID</th>
                <th>Nom</th>
                <th>Téléphone</th>
                <th>KYC</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $pending = $u->kyc()->where('status','pending')->count();
                    $approved = $u->kyc()->where('status','approved')->count();
                ?>

                <tr>
                    <td><?php echo e($u->obp_id); ?></td>
                    <td><?php echo e($u->name); ?></td>
                    <td><?php echo e($u->phone); ?></td>

                    <td>
                        <?php if($approved > 0): ?>
                            <span class="badge-modern badge-approved">Validé</span>
                        <?php elseif($pending > 0): ?>
                            <span class="badge-modern badge-pending">En attente</span>
                        <?php else: ?>
                            <span class="badge-modern badge-none">Aucun</span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($u->created_at->format('d/m/Y')); ?></td>

                    <td>
                        <a href="<?php echo e(route('admin.users.show', $u->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="bi bi-eye"></i>
                        </a>

                        <a href="<?php echo e(route('admin.users.edit', $u->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil"></i>
                        </a>

                        <button class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo e($u->id); ?>)">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <!-- PAGINATION -->
    <div class="mt-3">
        <?php echo e($users->links('pagination::bootstrap-5')); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
/* -------------------------
       CLIENT SEARCH
------------------------- */
function filterUsers() {
    let input = document.getElementById("userSearch").value.toLowerCase();
    let rows = document.querySelectorAll("#usersTable tbody tr");

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
}

/* -------------------------
         EXPORT CSV
------------------------- */
function exportUsersCSV() {
    let rows = Array.from(document.querySelectorAll("#usersTable tr"));
    let csv = rows.map(row =>
        Array.from(row.querySelectorAll("th,td"))
             .map(cell => `"${cell.innerText}"`)
             .join(",")
    ).join("\n");

    let blob = new Blob([csv], { type: "text/csv" });
    let url = window.URL.createObjectURL(blob);

    let a = document.createElement("a");
    a.href = url;
    a.download = "utilisateurs.csv";
    a.click();
}

/* -------------------------
          DELETE USER
------------------------- */
function deleteUser(id) {
    if (!confirm("Supprimer cet utilisateur ?")) return;

    fetch(`/admin/users/${id}`, {
        method: 'DELETE',
        headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"}
    }).then(() => location.reload());
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/users/index.blade.php ENDPATH**/ ?>