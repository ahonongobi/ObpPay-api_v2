<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>" 
          class="bg-white p-8 rounded shadow w-96">

        <?php echo csrf_field(); ?>

        <h1 class="text-xl font-bold mb-6">Admin Login</h1>

        <label class="block mb-2">Phone</label>
        <input type="text" name="phone" class="w-full p-2 border rounded mb-4">

        <label class="block mb-2">Password</label>
        <input type="password" name="password" class="w-full p-2 border rounded mb-4">

        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-600 mb-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="bg-blue-600 text-white w-full py-2 rounded">
            Login
        </button>

    </form>

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/login.blade.php ENDPATH**/ ?>