 <style>
    /* -------------------------------------------
   TEXT MUTED FIX (Bootstrap .text-muted)
------------------------------------------- */

/* Light mode muted */
.text-muted {
    color: #6c757d !important;
}

/* Dark mode muted */
body.dark-mode .text-muted {
    color: #9ca3af !important;
}
 </style>




<?php $__env->startSection('content'); ?>
<div class="settings-card shadow-lg">

    <div class="section-title text-secondary">Historique des actions administratives</div>

    <div class="table-card mt-3">
        <table class="table-modern w-100">
            <thead>
                <tr>
                    <th>Admin</th>
                    <th>Action</th>
                    <th>Type</th>
                    <th>Détails</th>
                    <th>Date</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->admin->name); ?></td>
                    <td><?php echo e($log->action); ?></td>
                    <td>
                        <span class="badge bg-info text-dark"><?php echo e(ucfirst($log->type)); ?></span>
                    </td>
                    <td>
                        <?php if($log->details): ?>
                            <small class="text-muted"><?php echo e(json_encode($log->details)); ?></small>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($log->created_at->format('d/m/Y H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="d-flex justify-content-center mt-3">
            <?php echo e($logs->links('vendor.pagination.custom')); ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/settings/index.blade.php ENDPATH**/ ?>