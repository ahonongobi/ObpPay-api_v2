<?php $__env->startSection('content'); ?>

<h1 class="fw-bold text-primary mb-4">Demandes d’aide / Prêts</h1>

<div class="table-card shadow-lg">
    <table class="table-modern">
        <thead>
            <tr>
                <th>#ID</th>
                <th>Utilisateur</th>
                <th>Catégorie</th>
                <th>Montant</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loan->id); ?></td>
                <td><?php echo e($loan->user->name); ?></td>
                <td><?php echo e($loan->category); ?></td>
                <td><?php echo e(number_format($loan->amount, 0)); ?> XOF</td>

                <td>
                    <?php if($loan->status == 'approved'): ?>
                        <span class="badge-modern badge-approved">Approuvé</span>
                    <?php elseif($loan->status == 'pending'): ?>
                        <span class="badge-modern badge-pending">En attente</span>
                    <?php else: ?>
                        <span class="badge-modern badge-none">Rejeté</span>
                    <?php endif; ?>
                </td>

                <td><?php echo e($loan->created_at->format('d/m/Y')); ?></td>

                <td>
                    <a href="<?php echo e(route('admin.loans.show', $loan->id)); ?>" 
                       class="btn btn-sm btn-primary">
                       Voir
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($loans->links('vendor.pagination.custom')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/obppay-backend/resources/views/admin/loan/index.blade.php ENDPATH**/ ?>