
<?php

return [
    'transfer_to_gsm' => 0.01795, // 1,795%
    'withdraw' => 0.01485, // 1,485%
    'transfer_obppay_to_obppay' => 65, // XOF fixe
    'weekly_interest' => 0.01595, // 1,595%
    'weekly_penalty' => 0.03495, // 3,495%
];
