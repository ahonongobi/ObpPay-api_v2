<div class="modal fade" id="kycModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Détails KYC</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div id="modalContent" class="text-center p-3">
                    <div class="spinner-border text-primary"></div>
                </div>

            </div>

            <div class="modal-footer d-flex justify-content-between">
                <button class="btn btn-danger" id="rejectBtn">Rejeter</button>
                <button class="btn btn-success" id="approveBtn">Approuver</button>
            </div>

        </div>
    </div>
</div>
